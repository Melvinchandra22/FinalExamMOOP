package com.example.melvinchandra.finalexams6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    double NumberOfSurviveCalvary;
    double NumberOfSurviveInfantry;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button button = (Button) findViewById(R.id.button_id);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Player p1 = new Player("Player 1");
                Player p2 = new Player("Player 2");

                Calvary cal = new Calvary();
                Infantry inf = new Infantry();
                ArmyCalvary AC = new ArmyCalvary();
                ArmyInfantry AI = new ArmyInfantry();
                cal.getAttackCalvary();
                inf.getAttackInfantry();

                AC.getNumbersOfArmy();
                AI.getNumbersOfArmy();

                NumberOfSurviveCalvary = (5*cal.getAttackCalvary())+(AC.getNumbersOfArmy()*2+100000);
                NumberOfSurviveInfantry = (5* inf.getAttackInfantry())+(AI.getNumbersOfArmy()*2+100000);

                if (NumberOfSurviveCalvary > NumberOfSurviveInfantry){
                    TextView result = (TextView) findViewById(R.id.result);
                    result.setText("Player 1 WIN !");
                }else if (NumberOfSurviveCalvary < NumberOfSurviveInfantry){
                    TextView result = (TextView) findViewById(R.id.result);
                    result.setText("Player 2 WIN !");
                }

            }
        });
    }

}

