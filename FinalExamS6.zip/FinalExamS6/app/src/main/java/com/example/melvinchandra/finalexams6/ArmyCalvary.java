package com.example.melvinchandra.finalexams6;


   public class ArmyCalvary{

       private int NumbersOfArmy;

       public int getNumbersOfArmy() {
           return NumbersOfArmy;
       }

       public void setNumbersOfArmy(int numbersOfArmy) {
           NumbersOfArmy = 100000;
       }

    }
