package com.example.melvinchandra.finalexams6;

public class Infantry {
    private double AttackInfantry;

    public double getAttackInfantry() {
        return AttackInfantry;
    }

    public void setAttackInfantry(double attackInfantry) {
        AttackInfantry = 0.1;
    }
}
