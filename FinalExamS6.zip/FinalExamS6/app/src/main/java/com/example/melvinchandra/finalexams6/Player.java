package com.example.melvinchandra.finalexams6;

public class Player {
    private String playerName;

    public Player(String s) {
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }


}
