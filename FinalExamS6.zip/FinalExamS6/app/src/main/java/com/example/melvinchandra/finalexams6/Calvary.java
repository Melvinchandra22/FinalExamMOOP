package com.example.melvinchandra.finalexams6;

public class Calvary {
    private double AttackCalvary;

    public double getAttackCalvary() {
        return AttackCalvary;
    }

    public void setAttackCalvary(int attackCalvary) {
        AttackCalvary = 0.4;
    }

}
